package com.navulia.management.onboardingservice.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.navulia.management.onboardingservice.dto.OnboardingServiceInputDto;
import com.navulia.management.onboardingservice.dto.OnboardingServiceOutputDto;
import com.navulia.management.onboardingservice.entity.Request;
import com.navulia.management.onboardingservice.entity.Question;
import com.navulia.management.onboardingservice.repository.OnboardingServiceRepository;

@Service
public class OnboardingDataService {

	private final OnboardingServiceRepository repository;

	@Autowired
	public OnboardingDataService(OnboardingServiceRepository repository) {
		this.repository = repository;
	}

	public OnboardingServiceOutputDto saveOnboardingRequest(OnboardingServiceInputDto formDataInputDto) {
		String uniqueId = UUID.randomUUID().toString();
	    Request formData = formDataInputDto.toEntity();
	    formData.setId(uniqueId);
	    formData.setCreatedAt(LocalDateTime.now());
	    if (formData.getQuestions() != null) {
	        List<Question> questions = formData.getQuestions();
	        for (Question question : questions) {
	            question.setId(uniqueId);
	        }
	    }
	    
	    Request savedFormData = repository.save(formData);

	    return savedFormData.viewAsOutputDto();
	}

	public OnboardingServiceOutputDto updateOnboardingRequestWithId(String id, OnboardingServiceInputDto inputDto) {
        Request existingFormData = repository.findById(id).orElse(null);

        if (existingFormData != null) {
            String uniqueId = existingFormData.getId();
            Request formData = inputDto.toEntity();
            formData.setId(uniqueId);
            formData.setCreatedAt(LocalDateTime.now());

            if (formData.getQuestions() != null) {
                List<Question> questions = formData.getQuestions();
                for (Question question : questions) {
                    question.setId(uniqueId);
                }
            } else {
                formData.setQuestions(new ArrayList<>());
            }

            Request savedFormData = repository.save(formData);

            return savedFormData.viewAsOutputDto();
        } else {
            return null;
        }
	}
}
