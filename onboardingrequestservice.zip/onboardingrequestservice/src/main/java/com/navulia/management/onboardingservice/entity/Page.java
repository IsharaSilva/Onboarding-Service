package com.navulia.management.onboardingservice.entity;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Page {
    private int index;
    private String id;
    private String title;
    private List<Question> questions;
}
