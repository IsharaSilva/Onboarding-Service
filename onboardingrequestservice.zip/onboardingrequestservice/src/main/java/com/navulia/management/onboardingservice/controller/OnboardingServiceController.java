package com.navulia.management.onboardingservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.navulia.management.onboardingservice.dto.OnboardingServiceInputDto;
import com.navulia.management.onboardingservice.dto.OnboardingServiceOutputDto;
import com.navulia.management.onboardingservice.service.OnboardingDataService;

@RestController
@RequestMapping("/api/onboardingService")
public class OnboardingServiceController {

	private final OnboardingDataService formSubmissionService;

	@Autowired
	public OnboardingServiceController(OnboardingDataService formSubmissionService) {
		this.formSubmissionService = formSubmissionService;
	}

	@PostMapping
	public OnboardingServiceOutputDto createOnboardingRequest(@RequestBody OnboardingServiceInputDto formDataInputDto) {
		return formSubmissionService.saveOnboardingRequest(formDataInputDto);
	}

	@PutMapping("/{id}")
	public OnboardingServiceOutputDto updateOnboardingRequest(@PathVariable String id, @RequestBody OnboardingServiceInputDto formDataInputDto) {
		return formSubmissionService.updateOnboardingRequestWithId(id, formDataInputDto);
	}
}
