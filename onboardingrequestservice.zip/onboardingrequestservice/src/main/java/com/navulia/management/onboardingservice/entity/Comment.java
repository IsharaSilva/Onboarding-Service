package com.navulia.management.onboardingservice.entity;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Comment {
	private String commentedBy;
	private LocalDateTime commentedAt;
	private String comment;

	public Comment(String commentedBy, String comment) {
		this.commentedBy = commentedBy;
		this.comment = comment;
		this.commentedAt = LocalDateTime.now();
	}
}
