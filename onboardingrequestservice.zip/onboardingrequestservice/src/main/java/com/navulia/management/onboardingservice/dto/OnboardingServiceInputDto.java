package com.navulia.management.onboardingservice.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.navulia.management.onboardingservice.entity.Comment;
import com.navulia.management.onboardingservice.entity.Page;
import com.navulia.management.onboardingservice.entity.Request;
import com.navulia.management.onboardingservice.entity.Question;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class OnboardingServiceInputDto {
	private LocalDateTime createdAt;
	private String createdBy;
	private LocalDateTime modifiedAt;
	private String modifiedBy;
	private String name;
	private String title;
	private String questionnaireId;
	private List<Comment> comments;
	private List<Page> pages;
	private String initiator;
	private String reviewer;
	private String approver;

	public Request toEntity() {
		Request formData = new Request();
		formData.setCreatedAt(this.createdAt);
		formData.setCreatedBy(this.createdBy);
		formData.setModifiedAt(this.modifiedAt);
		formData.setModifiedBy(this.modifiedBy);
		formData.setName(this.name);
		formData.setTitle(this.title);
		formData.setQuestionnaireId(this.questionnaireId);
		formData.setInitiator(this.initiator);
		formData.setReviewer(this.reviewer);
		formData.setApprover(this.approver);

		/*
		 * List<Question> noOfQuestions = this.questions.stream() .map(questionDto ->
		 * new Question(questionDto.getId(), questionDto.getResponse())) .toList();
		 * formData.setQuestions(noOfQuestions);
		 */

		List<Page> pageList = new ArrayList<>();
		if (pages != null) {
			pageList = this.pages.stream()
				.map(pageDto -> {
					Page page = new Page();
					page.setIndex(pageDto.getIndex());
					page.setId(pageDto.getId());
					page.setTitle(pageDto.getTitle());

					List<Question> questionList = new ArrayList<>();
					if (pageDto.getQuestions() != null) {
						questionList = pageDto.getQuestions().stream()
							.map(questionDto -> {
								Question question = new Question();
								question.setId(questionDto.getId());
								question.setResponse(questionDto.getResponse());
								return question;
							})
							.toList(); 
					}

					page.setQuestions(questionList);
					return page;
				})
				.toList(); 
		}

		formData.setPages(pageList);

        formData.setPages(pageList);

		List<Comment> commentList = this.comments.stream()
				.map(commentDto -> {
					Comment comment = new Comment(commentDto.getCommentedBy(), commentDto.getComment());
					comment.setCommentedAt(LocalDateTime.now());
					return comment;
				})
				.toList();
			formData.setComments(commentList);
		
		return formData;
	}
}
