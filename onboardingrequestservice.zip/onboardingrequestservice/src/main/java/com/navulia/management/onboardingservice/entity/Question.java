package com.navulia.management.onboardingservice.entity;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor 
@Document(collection = "questions")
public class Question {

	@Id
	private String id;
	private List<String> response;

    public Question(List<String> response) {
        this.response = response;
    }
}
