package com.navulia.management.onboardingservice.dto;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.navulia.management.onboardingservice.entity.Comment;
import com.navulia.management.onboardingservice.entity.Page;
import com.navulia.management.onboardingservice.entity.Question;

import lombok.Getter;

@Getter
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class OnboardingServiceOutputDto extends OnboardingServiceInputDto {
	private final String id;

    @JsonIgnore
    private final List<Question> questions;

    public OnboardingServiceOutputDto(String id, LocalDateTime createdAt, String createdBy, LocalDateTime modifiedAt,
            String modifiedBy, String name, String title, String questionnaireId, List<Question> questions,
            List<Comment> comments, List<Page> pages, String initiator, String reviewer, String approver) {
        super(createdAt, createdBy, modifiedAt, modifiedBy, name, title, questionnaireId, comments, pages, initiator, reviewer, approver);
        this.id = id;
        this.questions = questions;
	}
}
