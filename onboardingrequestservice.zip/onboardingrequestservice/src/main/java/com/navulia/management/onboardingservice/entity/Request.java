package com.navulia.management.onboardingservice.entity;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import com.navulia.management.onboardingservice.dto.OnboardingServiceOutputDto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Document(collection = "form_submissions")
public class Request {

	@Id
	private String id;
	@CreatedDate
	private LocalDateTime createdAt;

	private String createdBy;
	@LastModifiedDate
	private LocalDateTime modifiedAt;
	private String modifiedBy;
	private String name;
	private String title;
	private String questionnaireId;
	private List<Question> questions;
	private List<Comment> comments;
	private List<Page> pages;
	private String initiator;
	private String reviewer;
	private String approver;

	public OnboardingServiceOutputDto viewAsOutputDto() {
		return new OnboardingServiceOutputDto(id, createdAt, createdBy, modifiedAt, modifiedBy, name, title, questionnaireId,
				questions, comments, pages, initiator, reviewer, approver);
	}
}
